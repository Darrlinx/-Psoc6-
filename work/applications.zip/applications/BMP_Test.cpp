//#include <Wire.h>
//#include <SPI.h>
//#include <Adafruit_BMP280.h>
//#include "RTduino.h"
//#include "Config.h"
//
//#if defined IOT_THREAD_ENABLE
//
//#define BMP_EVENT 1 << 1                //BMP采集数据
//
//extern rt_event_t IOT_EVENT;            //IOT事件集
//rt_mq_t Air_Pressure_MQ = RT_NULL;      //传递给IOT线程的消息队列
//
//#endif
//
//#if defined DIS_THREAD_ENABLE
//
//rt_mq_t Air_Pressure_MQ_Dis = RT_NULL;  //传递给Dis线程的消息队列
//
//#endif
//
//float Air_Data[2] = {0};                //数据收集
//
//Adafruit_BMP280 bmp;                    // I2C
//
//void BMP_setup() {
//  Serial.begin();
//
//#if defined IOT_THREAD_ENABLE
//    Air_Pressure_MQ = rt_mq_create("Air_Mq", 8, 10, RT_IPC_FLAG_PRIO);
//    if(Air_Pressure_MQ == RT_NULL)
//    {
//      Serial.println("MessageQueue_IOT Create Error");
//    }
//#endif
//
//#if defined DIS_THREAD_ENABLE
//    Air_Pressure_MQ_Dis = rt_mq_create("Air_Mq_Dis", 8, 10, RT_IPC_FLAG_PRIO);
//    if(Air_Pressure_MQ_Dis == RT_NULL)
//    {
//      Serial.println("MessageQueue_Dis Create Error");
//    }
//#endif
//
//  while ( !Serial ) delay(100);   // wait for native usb
//  Serial.println(F("BMP280 test"));
//  unsigned status;
//  status = bmp.begin();
//  if (!status) {
//    Serial.println(F("Could not find a valid BMP280 sensor, check wiring or "
//                      "try a different address!"));
//    Serial.print("SensorID was: 0x"); Serial.println(bmp.sensorID(),16);
//    Serial.print("        ID of 0xFF probably means a bad address, a BMP 180 or BMP 085\n");
//    Serial.print("   ID of 0x56-0x58 represents a BMP 280,\n");
//    Serial.print("        ID of 0x60 represents a BME 280.\n");
//    Serial.print("        ID of 0x61 represents a BME 680.\n");
//    while (1) delay(10);
//  }
//
//  /* Default settings from datasheet. */
//  bmp.setSampling(Adafruit_BMP280::MODE_NORMAL,     /* Operating Mode. */
//                  Adafruit_BMP280::SAMPLING_X2,     /* Temp. oversampling */
//                  Adafruit_BMP280::SAMPLING_X16,    /* Pressure oversampling */
//                  Adafruit_BMP280::FILTER_X16,      /* Filtering. */
//                  Adafruit_BMP280::STANDBY_MS_500); /* Standby time. */
//}
//
//void BMP_loop() {
//    Air_Data[0] = bmp.readTemperature();
//    Air_Data[1] = bmp.readPressure();
//
//#ifndef NO_USING_DATA_OUTPUT
//    Serial.print(F("Temperature = "));
//    Serial.print(Air_Data[0]);
//    Serial.println(" *C");
//
//    Serial.print(F("Pressure = "));
//    Serial.print(Air_Data[1]);
//    Serial.println(" Pa");
//
//    Serial.print(F("Approx altitude = "));
//    Serial.print(bmp.readAltitude(1013.25)); /* Adjusted to local forecast! */
//    Serial.println(" m");
//#endif
//
//#if defined IOT_THREAD_ENABLE
//    //当启动IOT线程的时候
//    if(IOT_EVENT != RT_NULL)
//    {
//        //触发事件，通知IOT线程来取
//        if(rt_event_send(IOT_EVENT, BMP_EVENT) != RT_EOK)
//        {
//            Serial.println("Air_P Event Send Error");
//        }
//        //使用消息队列，将数据传输给IOT线程
//        if(rt_mq_send_wait(Air_Pressure_MQ, &Air_Data, 8, 100) != RT_EOK)
//        {
//            Serial.println("Air_P MQ Send To IOT Error");
//        }
//    }
//#endif
//
//#if defined DIS_THREAD_ENABLE
//    //使用消息队列，将数据传输到Display线程
//    if(rt_mq_send_wait(Air_Pressure_MQ_Dis, &Air_Data, 8, 1000) != RT_EOK)
//    {
//        Serial.println("Air_P MQ Send To Dis Error");
//    }
//#endif
//
//    delay(500);
//}
//
////初始化RTduino线程
//static int rtduino_init(void)
//{
//    rtduino_sketch_loader_create("RT_BMP", BMP_setup, BMP_loop);
//    return 0;
//}
//INIT_COMPONENT_EXPORT(rtduino_init);
