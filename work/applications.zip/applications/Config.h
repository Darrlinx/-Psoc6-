#ifndef __CONFIG_H_
#define __CONFIG_H_

//#define NO_USING_DATA_OUTPUT     //是否使用数据输出
#define DIS_THREAD_ENABLE        //打开DIS线程
//#define IOT_THREAD_ENABLE        //打开IOT线程


#endif //__CONFIG_H_
